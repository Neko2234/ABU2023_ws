#ifndef _ROS_adbot_msgs_SprMsg_h
#define _ROS_adbot_msgs_SprMsg_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace adbot_msgs
{

  class SprMsg : public ros::Msg
  {
    public:
      typedef bool _isOn_type;
      _isOn_type isOn;

    SprMsg():
      isOn(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_isOn;
      u_isOn.real = this->isOn;
      *(outbuffer + offset + 0) = (u_isOn.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->isOn);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_isOn;
      u_isOn.base = 0;
      u_isOn.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->isOn = u_isOn.real;
      offset += sizeof(this->isOn);
     return offset;
    }

    virtual const char * getType() override { return "adbot_msgs/SprMsg"; };
    virtual const char * getMD5() override { return "7815df4e3625e249c3731540caef0458"; };

  };

}
#endif
